package com.azasensi.app;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    static final int RED = 0xFFE10600, RED2 = 0xFFFF3B30, TXT = 0xFFF5EAEA, MUT = 0xFFB58C8C, LINE = 0xFF5A1317, FIELD = 0xFF0D0304;
    static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT, WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    static final int[][] BASE = {{185, 180, 172, 166, 155, 150}, {175, 170, 162, 156, 146, 140}, {165, 160, 152, 146, 136, 130}};
    static final String[] K = {"Общая", "Красная точка", "2x прицел", "4x прицел", "AWM прицел", "Свободный обзор"};
    static final int[] STY = {-6, 0, 12};
    static final String[] STY_NAMES = {"Хедшоты", "Баланс", "Ближний бой"};

    interface Pick { void on(String s); }

    final List<String[]> rows = new ArrayList<>();
    String brand = "", model = "", last = "";
    int style = 1;
    TextView brandBtn, modelBtn, goBtn, resHead, resMeta, dpiNum, dpiText, instr, sub;
    final TextView[] styleBtns = new TextView[3];
    EditText nick;
    LinearLayout result, sliders, panel;
    ScrollView scroll;
    SharedPreferences sp;

    int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + .5f); }

    TextView tv(String t, float size, int color, int mode) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(size);
        v.setTextColor(color);
        if (mode == 1) v.setTypeface(Typeface.DEFAULT_BOLD);
        if (mode == 2) v.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
        return v;
    }

    GradientDrawable box(int fill, int stroke, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(r));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    LinearLayout.LayoutParams lp(int w, int h, float top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.topMargin = dp(top);
        return p;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("aza", MODE_PRIVATE);
        for (String part : Data.PARTS) for (String line : part.split("\n")) rows.add(line.split("\\|"));

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF0A0203);
        ImageView bg = new ImageView(this);
        bg.setImageResource(R.drawable.bg);
        bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(bg, new FrameLayout.LayoutParams(MATCH, MATCH));

        scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18), dp(14), dp(18), dp(30));
        scroll.addView(content, new ViewGroup.LayoutParams(MATCH, WRAP));
        root.addView(scroll, new FrameLayout.LayoutParams(MATCH, MATCH));

        // header
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = tv("AZA SENSI", 16, TXT, 2);
        head.addView(logo, new LinearLayout.LayoutParams(0, WRAP, 1));
        TextView shareTop = tv("Поделиться", 14, TXT, 0);
        shareTop.setPadding(dp(14), dp(9), dp(14), dp(9));
        shareTop.setBackground(box(0x66000000, RED2, 6));
        shareTop.setOnClickListener(v -> share(true));
        head.addView(shareTop);
        content.addView(head, lp(MATCH, WRAP, 0));

        // space for the characters in the background
        View spacer = new View(this);
        content.addView(spacer, lp(MATCH, (int) (getResources().getDisplayMetrics().heightPixels * 0.30f), 0));

        TextView t1 = tv("AZA", 54, TXT, 2);
        TextView t2 = tv("SENSI", 54, RED2, 2);
        t1.setShadowLayer(18, 0, 2, 0xFF000000);
        t2.setShadowLayer(26, 0, 0, 0xCCE10600);
        t1.setIncludeFontPadding(false);
        t2.setIncludeFontPadding(false);
        content.addView(t1, lp(WRAP, WRAP, 0));
        content.addView(t2, lp(WRAP, WRAP, 0));
        sub = tv("Подбор сенсы и DPI под твой телефон", 17, 0xFFE6CFCF, 0);
        sub.setShadowLayer(12, 0, 2, 0xFF000000);
        content.addView(sub, lp(WRAP, WRAP, 10));

        // panel
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18), dp(18), dp(18), dp(20));
        panel.setBackground(box(0xEB100405, LINE, 8));
        content.addView(panel, lp(MATCH, WRAP, 22));

        panel.addView(tv("Бренд", 13, MUT, 0));
        brandBtn = field();
        brandBtn.setOnClickListener(v -> {
            List<String> br = new ArrayList<>();
            for (String[] r : rows) if (!br.contains(r[0])) br.add(r[0]);
            pick("Бренд", br, s -> { brand = s; model = ""; refresh(); });
        });
        panel.addView(brandBtn, lp(MATCH, WRAP, 6));

        panel.addView(tv("Модель телефона", 13, MUT, 0), lp(WRAP, WRAP, 14));
        modelBtn = field();
        modelBtn.setOnClickListener(v -> {
            if (brand.isEmpty()) { Toast.makeText(this, "Сначала выбери бренд", Toast.LENGTH_SHORT).show(); return; }
            List<String> ms = new ArrayList<>();
            for (String[] r : rows) if (r[0].equals(brand)) ms.add(r[1]);
            pick("Модель — выбери из списка или найди поиском", ms, s -> { model = s; refresh(); });
        });
        panel.addView(modelBtn, lp(MATCH, WRAP, 6));

        panel.addView(tv("Твой ник в Free Fire (по желанию)", 13, MUT, 0), lp(WRAP, WRAP, 14));
        nick = new EditText(this);
        nick.setHint("Например, AZA");
        nick.setHintTextColor(0xFF7D5555);
        nick.setTextColor(TXT);
        nick.setTextSize(16);
        nick.setSingleLine(true);
        nick.setFilters(new InputFilter[]{new InputFilter.LengthFilter(20)});
        nick.setPadding(dp(14), dp(12), dp(14), dp(12));
        nick.setBackground(box(FIELD, LINE, 6));
        panel.addView(nick, lp(MATCH, WRAP, 6));

        LinearLayout sty = new LinearLayout(this);
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            TextView s = tv(STY_NAMES[i], 14, TXT, 0);
            s.setGravity(Gravity.CENTER);
            s.setPadding(dp(4), dp(13), dp(4), dp(13));
            s.setOnClickListener(v -> { style = idx; refresh(); if (result.getVisibility() == View.VISIBLE && !model.isEmpty()) show(false); });
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, WRAP, 1);
            if (i > 0) p.leftMargin = dp(8);
            sty.addView(s, p);
            styleBtns[i] = s;
        }
        panel.addView(sty, lp(MATCH, WRAP, 16));

        goBtn = tv("Подобрать настройки", 17, 0xFFFFFFFF, 2);
        goBtn.setGravity(Gravity.CENTER);
        goBtn.setPadding(dp(10), dp(16), dp(10), dp(16));
        goBtn.setBackground(box(RED, RED2, 6));
        goBtn.setOnClickListener(v -> {
            if (model.isEmpty()) Toast.makeText(this, "Выбери бренд и модель", Toast.LENGTH_SHORT).show();
            else show(true);
        });
        panel.addView(goBtn, lp(MATCH, WRAP, 16));

        // result
        result = new LinearLayout(this);
        result.setOrientation(LinearLayout.VERTICAL);
        result.setVisibility(View.GONE);
        panel.addView(result, lp(MATCH, WRAP, 24));
        resHead = tv("", 22, TXT, 2);
        resMeta = tv("", 13, MUT, 0);
        result.addView(resHead);
        result.addView(resMeta, lp(WRAP, WRAP, 2));
        sliders = new LinearLayout(this);
        sliders.setOrientation(LinearLayout.VERTICAL);
        result.addView(sliders);

        LinearLayout dpiBox = new LinearLayout(this);
        dpiBox.setGravity(Gravity.CENTER_VERTICAL);
        dpiBox.setPadding(dp(16), dp(14), dp(16), dp(14));
        dpiBox.setBackground(box(0x22E10600, RED, 6));
        dpiNum = tv("", 34, 0xFFFFFFFF, 2);
        dpiNum.setShadowLayer(20, 0, 0, RED);
        dpiBox.addView(dpiNum);
        dpiText = tv("", 14, 0xFFE6CFCF, 0);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, WRAP, 1);
        tp.leftMargin = dp(16);
        dpiBox.addView(dpiText, tp);
        result.addView(dpiBox, lp(MATCH, WRAP, 22));

        instr = tv("Как поставить DPI на Android:\n1. Настройки → О телефоне → 7 раз нажми на номер сборки.\n2. Для разработчиков → Минимальная ширина (Smallest width).\n3. Впиши число из карточки и перезагрузи телефон.", 14, 0xFFE6CFCF, 0);
        result.addView(instr, lp(WRAP, WRAP, 16));

        LinearLayout acts = new LinearLayout(this);
        TextView cp = tv("Скопировать", 15, TXT, 0);
        cp.setGravity(Gravity.CENTER);
        cp.setPadding(dp(8), dp(13), dp(8), dp(13));
        cp.setBackground(box(0, RED2, 6));
        cp.setOnClickListener(v -> {
            ((ClipboardManager) getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("aza", last));
            Toast.makeText(this, "Скопировано", Toast.LENGTH_SHORT).show();
        });
        TextView sh = tv("Поделиться", 15, 0xFFFFFFFF, 1);
        sh.setGravity(Gravity.CENTER);
        sh.setPadding(dp(8), dp(13), dp(8), dp(13));
        sh.setBackground(box(RED, RED2, 6));
        sh.setOnClickListener(v -> share(false));
        acts.addView(cp, new LinearLayout.LayoutParams(0, WRAP, 1));
        LinearLayout.LayoutParams sp2 = new LinearLayout.LayoutParams(0, WRAP, 1);
        sp2.leftMargin = dp(10);
        acts.addView(sh, sp2);
        result.addView(acts, lp(MATCH, WRAP, 18));
        result.addView(tv("Это стартовые значения: потренируйся 2–3 минуты и поправь каждый ползунок на 5–10 пунктов под свою руку.", 12, MUT, 0), lp(WRAP, WRAP, 14));

        setContentView(root);

        // restore saved choice
        brand = sp.getString("b", "");
        model = sp.getString("m", "");
        style = sp.getInt("s", 1);
        String nk = sp.getString("n", "");
        nick.setText(nk);
        if (!nk.isEmpty()) sub.setText("С возвращением, " + nk + ". Твой телефон уже выбран.");
        refresh();
        if (!model.isEmpty()) show(false);
    }

    TextView field() {
        TextView v = tv("", 16, TXT, 0);
        v.setGravity(Gravity.CENTER_VERTICAL);
        v.setMinHeight(dp(52));
        v.setPadding(dp(14), dp(10), dp(14), dp(10));
        v.setBackground(box(FIELD, LINE, 6));
        return v;
    }

    void pick(String title, List<String> items, Pick p) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(8), dp(16), 0);
        final EditText q = new EditText(this);
        q.setHint("Поиск");
        q.setSingleLine(true);
        final ListView lv = new ListView(this);
        final List<String> shown = new ArrayList<>(items);
        final ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, shown);
        lv.setAdapter(ad);
        if (items.size() > 12) box.addView(q);
        box.addView(lv, new LinearLayout.LayoutParams(MATCH, dp(360)));
        final AlertDialog dlg = new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(title).setView(box).create();
        q.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            public void afterTextChanged(Editable e) { }
            public void onTextChanged(CharSequence s, int a, int b, int c) {
                String f = s.toString().toLowerCase().trim();
                shown.clear();
                for (String it : items) if (it.toLowerCase().contains(f)) shown.add(it);
                ad.notifyDataSetChanged();
            }
        });
        lv.setOnItemClickListener((parent, view, pos, id) -> { dlg.dismiss(); p.on(shown.get(pos)); });
        dlg.show();
    }

    void refresh() {
        brandBtn.setText((brand.isEmpty() ? "Выбери бренд" : brand) + "   ▾");
        modelBtn.setText((model.isEmpty() ? (brand.isEmpty() ? "Сначала выбери бренд" : "Выбери модель") : model) + "   ▾");
        goBtn.setAlpha(model.isEmpty() ? .45f : 1f);
        for (int i = 0; i < 3; i++) {
            styleBtns[i].setBackground(i == style ? box(RED, RED2, 6) : box(FIELD, LINE, 6));
            styleBtns[i].setTextColor(i == style ? 0xFFFFFFFF : TXT);
        }
    }

    int[] calc(int tier, int hz) {
        int adj = (hz >= 120 ? -6 : hz >= 90 ? -3 : 0) + STY[style];
        int[] v = new int[6];
        for (int i = 0; i < 6; i++)
            v[i] = Math.max(1, Math.min(200, BASE[tier - 1][i] + adj + (style == 0 && i >= 2 ? -4 : 0)));
        return v;
    }

    void show(boolean scrollTo) {
        String[] d = null;
        for (String[] r : rows) if (r[0].equals(brand) && r[1].equals(model)) d = r;
        if (d == null) return;
        int tier = Integer.parseInt(d[2]), dpi = Integer.parseInt(d[3]), hz = Integer.parseInt(d[4]);
        int[] v = calc(tier, hz);
        String nk = nick.getText().toString().trim();
        resHead.setText((nk.isEmpty() ? "" : nk + " · ") + d[0] + " " + d[1]);
        resMeta.setText(hz + " Гц · " + (tier == 1 ? "бюджетный" : tier == 2 ? "средний" : "флагманский") + " класс · " + STY_NAMES[style]);
        sliders.removeAllViews();
        StringBuilder sb = new StringBuilder("AZA SENSI\n");
        if (!nk.isEmpty()) sb.append("Ник: ").append(nk).append("\n");
        sb.append(d[0]).append(" ").append(d[1]).append("\n");
        for (int i = 0; i < 6; i++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.VERTICAL);
            LinearLayout top = new LinearLayout(this);
            top.setGravity(Gravity.CENTER_VERTICAL);
            top.addView(tv(K[i], 15, TXT, 0), new LinearLayout.LayoutParams(0, WRAP, 1));
            top.addView(tv(String.valueOf(v[i]), 19, RED2, 1));
            ProgressBar pb = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
            pb.setMax(200);
            pb.setProgressTintList(ColorStateList.valueOf(RED2));
            pb.setProgressBackgroundTintList(ColorStateList.valueOf(0xFF2A0A0C));
            row.addView(top);
            row.addView(pb, lp(MATCH, dp(10), 6));
            sliders.addView(row, lp(MATCH, WRAP, 14));
            ObjectAnimator a = ObjectAnimator.ofInt(pb, "progress", 0, v[i]);
            a.setDuration(700);
            a.start();
            sb.append(K[i]).append(": ").append(v[i]).append("\n");
        }
        if (dpi > 0) {
            dpiNum.setText(String.valueOf(dpi));
            dpiText.setText("Рекомендуемый DPI (минимальная ширина) для " + d[1] + ". Чем выше DPI, тем мельче интерфейс.");
            instr.setVisibility(View.VISIBLE);
            sb.append("DPI: ").append(dpi);
        } else {
            dpiNum.setText("Авто");
            dpiText.setText("На iPhone DPI изменить нельзя, стандартный уже подходит. Используй только ползунки сенсы.");
            instr.setVisibility(View.GONE);
            sb.append("DPI: Авто");
        }
        last = sb.toString();
        result.setVisibility(View.VISIBLE);
        sp.edit().putString("b", brand).putString("m", model).putInt("s", style).putString("n", nk).apply();
        if (scrollTo) scroll.post(() -> scroll.smoothScrollTo(0, panel.getTop() + result.getTop() - dp(8)));
    }

    void share(boolean site) {
        String t = (site || last.isEmpty()) ? "AZA SENSI — подбор сенсы и DPI для Free Fire под твой телефон" : last;
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, t);
        startActivity(Intent.createChooser(i, "Поделиться"));
    }
}
